# MHParallel
Metropolis-Hastings C++ implementation
