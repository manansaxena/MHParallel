#include <cmath>
#include <iostream>
#include <boost/math/distributions.hpp>
#include <boost/math/special_functions/log1p.hpp>
#include <boost/random.hpp>
#include <string>
#include <vector>
#include <omp.h>
// #include <trng/yarn2.hpp>
// #include <trng/normal_dist.hpp>
// #include <trng/uniform01_dist.hpp>
// #include "RcppEigen.h"
// #include "Rcpp.h"
// #include "Rcpp/Benchmark/Timer.h"


// auto initialize_rng_for_each_chain(int num_chain);

// auto target(int distribution, Eigen::VectorXd parameters, auto x);
// auto generate_proposals(int proposal_distribution, Eigen::VectorXd parameters, auto current_state, auto random_generator);
// auto metropolisHastings(auto initial_state, int shapeOfOneState, int num_chain, int num_steps_per_chain, int n_cores,int proposal_distribution, Eigen::VectorXd proposal_params);
// auto monte_carlo_chain(int chain_id, int num_steps_per_chain, auto initial_state, auto random_generator, int proposal_distribution, Eigen::VectorXd proposal_params);
// auto mh_step(auto random_generator, auto current_state, int proposal_distribution, Eigen::VectorXd parameters);

float target(int distribution, int parameters, float x);

template <class RNG>
float generate_proposals(int proposal_distribution, std::vector<float> parameters, float current_state, RNG& random_generator);

std::vector<std::vector<float>>  metropolisHastings(std::vector<float> initial_state, int num_chain, int num_steps_per_chain, int seed, int n_cores,int proposal_distribution, std::vector<float> proposal_params);

template <class RNG>
std::vector<float> monte_carlo_chain(int chain_id, int num_steps_per_chain, float initial_state, RNG& random_generator, int proposal_distribution, std::vector<float> proposal_params);

template <class RNG>
float mh_step(RNG& random_generator, float current_state, int proposal_distribution, std::vector<float> parameters);
