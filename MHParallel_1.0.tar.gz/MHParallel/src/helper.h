#include <RcppEigen.h>
// [[Rcpp::depends(RcppEigen)]]

using namespace Rcpp;
using namespace Eigen;


List convertToRcppList(const std::vector<Eigen::MatrixXd> &matVec) {
    List rcppList(matVec.size());

    for (size_t i = 0; i < matVec.size(); ++i) {
        rcppList[i] = wrap(matVec[i]);
    }

    return rcppList;
}
