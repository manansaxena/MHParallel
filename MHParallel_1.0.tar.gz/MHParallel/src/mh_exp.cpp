#include "mh_exp.h"
#include<fstream>


// specify the target distribution

float target(int distribution, int parameters, float x){
    // for exponential send only the lambda parameter
    if(distribution == 1){
        float lambda = parameters;
        if (x >= 0.0) {
            return std::log(lambda) - lambda * x;
        } else {
            return -std::numeric_limits<float>::infinity(); // Negative infinity for x < 0
        }
    }
    
}

template<class RNG>
float generate_proposals(int proposal_distribution,std::vector<float> parameters, float current_state, RNG& random_generator){
    float proposed_state = current_state;
    if(proposal_distribution == 0){
        // proposal distribtuion chosen is normal distribution
        float mean = parameters[0];
        float std = parameters[1];
        boost::random::normal_distribution<float> rnorm(mean, std);
        proposed_state = current_state + rnorm(random_generator);
    }   
    return proposed_state;
}

template<class RNG>
float mh_step(RNG& random_generator, float current_state, int proposal_distribution, std::vector<float> parameters){
    
    float proposed_state = generate_proposals(proposal_distribution, parameters, current_state, random_generator);
    float acceptance_ratio = std::min(float(1.0), std::exp(target(1,2,proposed_state) - target(1,2,current_state)));
    boost::random::uniform_real_distribution<float> uni_gen(0.0, 1.0);

    if(uni_gen(random_generator)<acceptance_ratio){
        return proposed_state;
    }
    else{
        return current_state; 
    }
}

template <class RNG>
std::vector<float> monte_carlo_chain(int chain_id, int num_steps_per_chain, float initial_state, RNG& random_generator, int proposal_distribution, std::vector<float> proposal_params){

    std::vector<float> states = {initial_state};
    for(int i=0;i<num_steps_per_chain;i++){  
        states.push_back(mh_step(random_generator, states.back(), proposal_distribution, proposal_params));  
    }
    return states;
}


std::vector<std::vector<float>> metropolisHastings(std::vector<float> initial_state, int num_chain, int num_steps_per_chain, int seed, int n_cores,int proposal_distribution, std::vector<float> proposal_params){
    


    if (n_cores > 0) {
      omp_set_num_threads(n_cores);
    } else {
      omp_set_num_threads(omp_get_max_threads());
    }
    
        
    std::vector<std::vector<float>> states(num_chain);

        
    #pragma omp parallel for
    for(int chain_id= 0; chain_id<num_chain;chain_id++){
        boost::random::mt19937 rng(seed);
        rng.discard(omp_get_thread_num()*num_steps_per_chain);
        std::cout << omp_get_thread_num() << std::endl;
        states[chain_id] = monte_carlo_chain(chain_id, num_steps_per_chain, initial_state[chain_id], rng, proposal_distribution, proposal_params);
    }

    return states;
}


int main(int argc, char const *argv[])
{    
    std::vector<float> initial_states = {0,1,2,3,4,5,6,7,8,9};
    int num_chain = 10;
    int num_steps_per_chain = 1000;
    int seed = 0;
    int n_cores = 4;
    int proposal_distribution = 0;
    std::vector<float> proposal_params = {0,1};

    std::vector<std::vector<float>> result = metropolisHastings(initial_states,num_chain,num_steps_per_chain,seed,n_cores,proposal_distribution,proposal_params);

    std::ofstream myFile("foo.csv");

    for(int i=0;i<result.size();i++){
        for(int j=0;j<result[i].size();j++){
            myFile << result[i][j] << ",";
        }
        myFile << "\n";
    }

    myFile.close();

    return 0;
}
