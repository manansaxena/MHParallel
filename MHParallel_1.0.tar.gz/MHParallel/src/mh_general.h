#include <cmath>
#include <iostream>
#include <boost/math/distributions.hpp>
#include <boost/math/special_functions/log1p.hpp>
#include <boost/random.hpp>
#include <string>
#include <vector>
#include <omp.h>
#include "RcppEigen.h"
#include "Rcpp.h"
#include "Rcpp/Benchmark/Timer.h"
#include <boost/math/distributions/beta.hpp>
#include <limits>

// [[Rcpp::plugins(openmp)]]



double target(const Eigen::VectorXd& x, double alpha = 4, double beta = 2) {
    using boost::math::beta_distribution;

    double result = 0.0;
    for (int i = 0; i < x.size(); ++i) {
        double xi = x(i);
        if (xi < 0 || xi > 1) {
            return -std::numeric_limits<double>::infinity();  // Return negative infinity if out of bounds
        }
        beta_distribution<double> dist(alpha, beta);
        result += log(boost::math::pdf(dist, xi));  // Accumulate log probability
    }
    return result;
}

/*
Input : 
    1) current_state: vector of current state of the sample in a metropolis chain
    2) random_vector: random vector of eq. distributed standard normal
Ouput :
    vector of new proposals
*/
Eigen::VectorXd generate_proposal(Eigen::VectorXd current_state, Eigen::VectorXd random_vector){
    return current_state + random_vector;
}


template<class RNG>
Eigen::VectorXd generate_random_vector(RNG& rng, int dim, Eigen::MatrixXd covar){
    Eigen::LLT<Eigen::MatrixXd> llt(covar);
    Eigen::MatrixXd L = llt.matrixL();
    assert(llt.info() != Eigen::NumericalIssue);
                
    boost::normal_distribution<> norm(0, 1);
    boost::variate_generator<boost::mt19937&, boost::normal_distribution<> > randn(rng, norm);
                
    Eigen::VectorXd z(dim);
    for (int i = 0; i < dim; ++i) {
        z(i) = randn();
    }
    return L * z;
}



// template<class RNG>
// Eigen::VectorXd mh_step(RNG& rng, Eigen::VectorXd current_state, double* proposal_accepted_cnt, Rcpp::Function target_ll, double scale_factor_of_proposal){
//     Eigen::MatrixXd covar = scale_factor_of_proposal * Eigen::MatrixXd::Identity(current_state.size(),current_state.size());
//     Eigen::VectorXd random_vector = generate_random_vector(rng, current_state.size(), covar);
//     Eigen::VectorXd proposed_state = generate_proposal(current_state, random_vector);

//     double acceptance_ratio = std::min(double(1.0), std::exp(Rcpp::as<double>(target_ll(proposed_state)) - Rcpp::as<double>(target_ll(current_state))));
//     boost::random::uniform_real_distribution<double> uni_gen(0.0, 1.0);

//     if(uni_gen(rng)<acceptance_ratio){
//         *proposal_accepted_cnt += 1;
//         return proposed_state;
//     }
//     else{
//         return current_state; 
//     }
// }

template<class RNG>
Eigen::VectorXd mh_step(RNG& rng, Eigen::VectorXd current_state, double* proposal_accepted_cnt, double scale_factor_of_proposal){
    Eigen::MatrixXd covar = scale_factor_of_proposal * Eigen::MatrixXd::Identity(current_state.size(),current_state.size());
    Eigen::VectorXd random_vector = generate_random_vector(rng, current_state.size(), covar);
    Eigen::VectorXd proposed_state = generate_proposal(current_state, random_vector);

    double acceptance_ratio = std::min(double(1.0), std::exp(target(proposed_state) - target(current_state)));
    boost::random::uniform_real_distribution<double> uni_gen(0.0, 1.0);

    if(uni_gen(rng)<acceptance_ratio){
        *proposal_accepted_cnt += 1;
        return proposed_state;
    }
    else{
        return current_state; 
    }
}


/*
Input : 
    1) num_chains : number of chains to be run in the metropolis algorithm
    2) initial_states: a vector of vectors of intial states. Shape: num_chains X size of each initial state
    3) num_steps : number of steps each chain should take during the metropolis algorithm
    4) seed: seed used to initialize
    5) n_cores : number of cores
    6) target_ll : a Rcpp functional type to calculate the log likelihood of our target distribution
*/
Rcpp::List metropolis_hastings (int num_chains,
                                std::vector<Eigen::VectorXd> initial_states,
                                int num_steps,
                                int seed,
                                int n_cores,
                                Rcpp::Function target_ll, 
                                double scale_factor_of_proposal
                                )

{
    Rcpp::Timer timer;
    timer.step("Overall Start");

    Rcpp::Rcout << "scale_factor_of_proposal: " << scale_factor_of_proposal << std::endl;
    Rcpp::List out(3);
    out.names() = Rcpp::CharacterVector::create("particles","accepted_counts","timer");

    if (n_cores > 0) {
      omp_set_num_threads(n_cores);
    } else {
      omp_set_num_threads(omp_get_max_threads());
    }

    // num_chains * (length of each state vector * num_steps) 
    std::vector<Eigen::MatrixXd> final_states(num_chains);
    std::vector<double> accepted_count(num_chains,0.0);
    
    #pragma omp parallel for 
    for(int chain_id = 0; chain_id < num_chains; chain_id++){
        boost::random::mt19937 rng(seed);
        rng.discard(omp_get_thread_num()*num_steps);

        Eigen::MatrixXd interim_states(initial_states[chain_id].size(),num_steps+1);
        interim_states.col(0) = initial_states[chain_id];
        double proposal_accepted_cnt = 0.0;
        for(int i=0;i<num_steps;i++){
            // interim_states.col(i+1) = mh_step(rng, interim_states.col(i), &proposal_accepted_cnt, target_ll, scale_factor_of_proposal);
            interim_states.col(i+1) = mh_step(rng, interim_states.col(i),&proposal_accepted_cnt, scale_factor_of_proposal);

        }
        Rcpp::Rcout << "here" << std::endl;
        final_states[chain_id] = interim_states;
        accepted_count[chain_id] = proposal_accepted_cnt;
        Rcpp::Rcout << omp_get_thread_num() << std::endl;
    }

    timer.step("Overall Stop");
    Rcpp::NumericVector t(timer);
    out[0] = final_states;
    out[1] = accepted_count;
    out[2] = timer;
    return out;
}
